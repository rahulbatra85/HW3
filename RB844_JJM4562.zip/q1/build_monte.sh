g++ -fopenmp -g monte_carlo_pi.cpp -Wall -o monte_carlo_pi 
