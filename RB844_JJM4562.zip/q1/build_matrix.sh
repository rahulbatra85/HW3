g++ -fopenmp -g matrix_mult.cpp -Wall -o matrix_mult
